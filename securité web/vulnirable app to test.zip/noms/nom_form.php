<form method="post" action="">
   <p>Nom: <input type="text" name="nom"/></p>
   <p>Prénom: <input type="text" name="prenom"/></p>
   <p>Age: <input type="number" name="age" /></p>
   <p><input type="submit" value="Ajouter" /></p> 
</form>