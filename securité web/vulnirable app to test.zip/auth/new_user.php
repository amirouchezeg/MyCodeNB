<?php

session_start();


include("db_config.php");

$page_title = "Ajout utilisateur";

include("header.php");


/*
include("auth.php");
$SQL = "SELECT id FROM users 
						 WHERE id='$_SESSION[USERID]' AND type='admin'";
$res = $db->query($SQL);


if (!$res || $res->rowCount()==0) {
		 echo "<P>Vous n'êtes pas autorisé à effectuer cette operation";
	 include("footer.php");
		 exit();
	 }
*/


if (!isset($_POST["login"]) || !isset($_POST["password"]) ||
		!isset($_POST["password2"])||!isset($_POST["fname"])||!isset($_POST["lname"])||
		empty($_POST["login"])||empty($_POST["password"]) || 
		empty($_POST["fname"])||empty($_POST["lname"]) ){
		echo "<p>Erreur dans les données\n";
		include("reg_form.php");
		include("footer.php");
	 exit();
}

if ($_POST["password"] != $_POST["password2"]){
		echo "<p>Mots de passe différents\n";
	 include("reg_form.php");
	 include("footer.php");
	 exit();
}


 
	$login = $db->quote($_POST["login"]);
	$passwd = $db->quote($_POST["password"]);
	$fname = $db->quote($_POST["fname"]);
	$lname = $db->quote($_POST["lname"]);

	$SQL = "SELECT ID
						 FROM users
						 WHERE login=$login";
	$res = $db->query($SQL);

	if ($res && $res->rowCount()>0) 
	{
		echo "<p>Le login existe\n";
		include("reg_form.php"); 
		include("footer.php");
		exit(); 
	} 


	$SQL = "INSERT INTO users
						 VALUES (DEFAULT,$lname,$fname,$login,MD5($passwd),'user')";
	$res = $db->query($SQL);

	if (!$res) die('Error: ' . $db->errorInfo()[2]); 
	
	
	echo "<p>Utilisateur $login ajouté\n";
	echo "<p><a href='index.php'>Revenir à la page d'accueil</a>\n";
	include("footer.php");

?>