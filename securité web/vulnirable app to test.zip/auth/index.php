<?php

include("auth.php");

include("header.php");

echo "<p>Bonjour $_SESSION[NAME]</p>";

echo "<a href=\"logout.php\">Deconnexion</a>";

include("footer.php");