<?php

session_start();

session_destroy();
include("header.php");
print("Sesion detruite...<BR>");
print("<a href=\"index.php\">Recommencer</a>");
include("footer.php");

?>