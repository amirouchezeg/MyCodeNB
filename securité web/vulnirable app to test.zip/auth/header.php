<html>
<head>
<title><?=$page_title?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style>
.center { text-align: center }
.center table {margin-left:auto; margin-right:auto;}
.left {text-align: right}
.right {text-align: left}
body {background-color: #DEDEDE}
</style>
</head>
<body>