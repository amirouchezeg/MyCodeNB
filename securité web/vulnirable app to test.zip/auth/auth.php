<?php

session_start();


if (!(isset($_SESSION["USERID"]))){
  if (!isset($_POST["login"]) || !isset($_POST["password"])){
    $badlogin=0;
    include("login_form.php");
    exit();
  }
// Verification Login


  include("db_config.php");

  $login = $db->quote($_POST["login"]);
  $passwd = $_POST["password"];

  $SQL = "SELECT *
             FROM users
             WHERE login=$login AND mdp=md5('$passwd')";
  $res = $db->query($SQL);

  if (!$res || $res->rowCount()==0) 
  {
    $badlogin=1;
    include("login_form.php"); 
    exit(); 
  } else {
 	$row=$res->fetch();
    $_SESSION["NAME"] = $row['nom'];
    $_SESSION["USERID"] = $row['id'];
  }
  

}