<p class='center'>Introduisez vos données:

<div class='center'>
<form method="POST" name="loginform">
  <table>
    <tr>
      <td class='left'>Nom: </td>
      <td class='right'><input type="text" name="lname" size="20"></td>
    </tr>
    <tr>
      <td class='left'>Prénom: </td>
      <td class='right'><input type="text" name="fname" size="20"></td>
    </tr>
    <tr>
      <td class='left'>Login: </td>
      <td class='right'><input type="text" name="login" size="20"></td>
    </tr>
    <tr>
      <td class=left align=right>Mot de passe:</td>
      <td class=right><input type="password" name="password" size="20"></td>
    </tr>
    <tr>
      <td class='left'>Répéter le mot de passe:</td>
      <td class='right'><input type="password" name="password2" size="20"></td>
    </tr>
  </table>
<table cellspacing=5>
 <tr>
  <td class='left'><input type="submit" value="Valider" /></td>
  <td class='right'><input type="reset" value="Recommencer" /></td>
 </tr>
</table>
</form>
</div>