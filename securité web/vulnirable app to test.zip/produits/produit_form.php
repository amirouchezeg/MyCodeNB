<form method="post" action="">
   <p>Nom: <input type="text" name="nom"/></p>
   <p>Prix: <input type="number" name="prix" /></p>
   <p><input type="submit" value="Ajouter" /></p> 
</form>