extern "C" 
{ 
    int __attribute__((weak))  showMessage(); 
}

void test_showmessage();
