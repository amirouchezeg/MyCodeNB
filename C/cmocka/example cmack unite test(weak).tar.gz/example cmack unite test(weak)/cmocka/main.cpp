#include "show.h"

#include "stdio.h"

int main()
{
    test_showmessage();
    return 0;
}
