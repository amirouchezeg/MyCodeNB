#include "stdio.h"
extern "C" 
{
    int showMessage()
    {
        printf("this message from the __wrap_showMessage()\n");
        return 1;
    }
    
}

 
