
#include "stdio.h"

 
extern "C" 
{
    int __attribute__((weak))  showMessage() 
    {
        printf("this message from the showMessage()\n");
        return 0;
    } 
}

void test_showmessage()
{
    showMessage();
}
